package control;

public class BookRecipe {

}

package control;

public class Main {
	public static void main(String[] args) {
		Routes.newRoutes();
	}
}
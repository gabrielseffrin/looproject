package control;

public class SearchRecipe {

}

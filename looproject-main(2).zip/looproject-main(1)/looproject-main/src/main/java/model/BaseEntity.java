package model;

public interface BaseEntity {
	public long getId();
}
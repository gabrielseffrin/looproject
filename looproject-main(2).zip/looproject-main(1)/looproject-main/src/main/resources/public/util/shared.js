$(function () {
    $('#header').load('/header');
    $('#footer').load('/footer');
    $('#min-menu').load('/minMenu')
});